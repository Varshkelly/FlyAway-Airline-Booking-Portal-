package com.anychart.listeners;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.mysql.cj.jdbc.MysqlDataSource;

public class DatabaseContextLIstener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();
        MysqlDataSource ds = new MysqlDataSource();
        ds.setDatabaseName("db_world");
        ds.setUser("root");
        ds.setPassword("Varsha@jana123");
        context.setAttribute("DBDataSource", ds);
    }

    public void contextDestroyed(ServletContextEvent sce) {
    }
}
