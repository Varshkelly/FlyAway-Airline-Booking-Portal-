package com.anychart.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.anychart.models.FlightDetails;
import com.anychart.models.RegisterDetails;
import com.mysql.cj.jdbc.MysqlDataSource;

/**
 * Servlet implementation class ReviewServlet
 */
@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session= req.getSession(); 

		String flightId=(String)session.getAttribute("user_flight_Id");
		String emailId=(String)session.getAttribute("user_email_Id");
		
		
	  	MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");
	  	String flightStatus = "";
    	Connection conn;
    	PreparedStatement stmt;
    	PreparedStatement stmt1;
    	List<FlightDetails> flights = new ArrayList<FlightDetails>();
    	List<RegisterDetails> registered_user = new ArrayList<RegisterDetails>();
    	String testName ="";
    	
    	try {
    			                  		
    		 conn = ds.getConnection();
    		 stmt = conn.prepareStatement("INSERT INTO FlightBooking (flight_no_ID, emailid_ID) values (?,?)");     
             stmt.setString(1, flightId);
             stmt.setString(2, emailId);
    	     stmt.execute();            
	       
	         			        	
    	} 
    	catch (Exception e) {
    		e.printStackTrace();
    	}        			


        req.getRequestDispatcher("/WEB-INF/views/Booking.jsp").forward(req, res);

    	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

	}

}
