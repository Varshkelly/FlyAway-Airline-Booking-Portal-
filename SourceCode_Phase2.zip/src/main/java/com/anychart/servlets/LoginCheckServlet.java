package com.anychart.servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.jdbc.MysqlDataSource;


public class LoginCheckServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       
			String username = req.getParameter("username");
			String pass = req.getParameter("pwd");
			HttpSession session= req.getSession(); 

			
			  	MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");
			  	String loginStatus = "";
	        	Connection conn;
	        	PreparedStatement stmt;
	        	String user_pass = "";
	        	try {
	        			 conn = ds.getConnection();
			             stmt = conn.prepareStatement("select password from AdminLogin where UsernameID = ? ");
			             stmt.setString(1, username);
			             ResultSet rs = stmt.executeQuery();
			        	 if(rs.next()) {
			        		user_pass= rs.getString("Password");
			        		if(pass.equals(user_pass)) {
			        			session.setAttribute("loggedin_user", username);
			        			loginStatus = "Success";
			        		} else {
			        			loginStatus = "Failed";
			        		}
			        	}
	        	} 
	        	catch (Exception e) {
	        		e.printStackTrace();
	        	}
		        
					req.setAttribute("logStatus", loginStatus);
		            req.getRequestDispatcher("/WEB-INF/views/Dashboard.jsp").forward(req, resp);
		    }  

}
