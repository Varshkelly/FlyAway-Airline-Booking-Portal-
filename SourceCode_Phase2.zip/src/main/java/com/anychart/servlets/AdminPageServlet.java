package com.anychart.servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.anychart.models.AdminLogin;

import com.mysql.cj.jdbc.MysqlDataSource;

public class AdminPageServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");

        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM AdminLogin")) {

            List<AdminLogin> userdetails = new ArrayList<AdminLogin>();
            // Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String UsernameID = rs.getString("UsernameID"); //air asis
                String password = rs.getString("password"); //90000
                
                AdminLogin al = new AdminLogin(UsernameID, password);
                userdetails.add(al);                
                // Add item
            }
            System.out.println(userdetails);

//            req.setAttribute("title", "Admin Details from Database");
//            req.setAttribute("userData", userdetails);
            req.getRequestDispatcher("/WEB-INF/views/AdminPage.jsp").forward(req, resp);
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
