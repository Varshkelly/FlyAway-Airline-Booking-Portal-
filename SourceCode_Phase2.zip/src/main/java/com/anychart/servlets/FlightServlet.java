package com.anychart.servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.anychart.models.FlightDetails;
import com.mysql.cj.jdbc.MysqlDataSource;


public class FlightServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       
		 String source_city = req.getParameter("city_selection");
		 String destination_city = req.getParameter("des_city_selection");
         String date_of_travel = req.getParameter("date_of_travel");
         
			
			  	MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");
//			  	String flightStatus = "";
	        	Connection conn;
	        	PreparedStatement stmt;
	        	List<FlightDetails> flights = new ArrayList<FlightDetails>();
	        	
	        	try {
	        			 conn = ds.getConnection();
			             stmt = conn.prepareStatement("select * from FlightDetails where source_city = ? and destination_city = ? and date_of_travel = ?");
			             stmt.setString(1, source_city);
			             stmt.setString(2, destination_city);
			             stmt.setString(3, date_of_travel);
			             
			             ResultSet rs = stmt.executeQuery();			             
			             // Extract data from result set
			             while (rs.next()) {
			                 //Retrieve by column name
			                 String airline_name = rs.getString("airline_name"); //air asis
			                 int price = rs.getInt("price");
			                 int flight_no_ID = rs.getInt("flight_no_ID");
			                 String source_city1 = rs.getString("source_city");
			                 String destination_city1 = rs.getString("destination_city");
			                 String departure_time = rs.getString("departure_time");
			                 String arrival_time = rs.getString("arrival_time");
			                 int total_seats = rs.getInt("total_seats");
			                 int booked_seats = rs.getInt("booked_seats");
			                 int available_seats = rs.getInt("available_seats");
			                 String date_of_travel1 = rs.getString("date_of_travel");			                 
			                 
			                 FlightDetails fd = new FlightDetails(airline_name, price, flight_no_ID, source_city1, destination_city1, departure_time,
			                 		arrival_time, total_seats, booked_seats, available_seats, date_of_travel1);
			                 flights.add(fd);                
			                 // Add item
			             }

			         			        	
	        	} 
	        	catch (Exception e) {
	        		e.printStackTrace();
	        	}
		        
						
					req.setAttribute("flightData", flights);	
					req.setAttribute("dateTravel", date_of_travel);	
		            req.getRequestDispatcher("/WEB-INF/views/FlyAway.jsp").forward(req, resp);
		    }  

}
