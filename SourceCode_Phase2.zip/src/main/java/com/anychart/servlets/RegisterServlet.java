package com.anychart.servlets;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.anychart.models.*;
import com.mysql.cj.jdbc.MysqlDataSource;

public class RegisterServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	@Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session= req.getSession(); 
		String flight_no_ID1 = req.getParameter("flight_booking");
		session.setAttribute("user_flight_Id", flight_no_ID1);
        
	            req.getRequestDispatcher("/WEB-INF/views/RegisterPage.jsp").forward(req, resp);
	    } 
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		HttpSession session= req.getSession(); 
		String emailId = req.getParameter("Email");
		session.setAttribute("user_email_Id", emailId);

		
        String FullName = req.getParameter("UserName");
		String Address = req.getParameter("Address");
		String Age = req.getParameter("Age");
		String mobile = req.getParameter("Mobile");
		String emailid_ID = req.getParameter("Email");
		String verification = req.getParameter("Verification");
		String country = req.getParameter("Country");
		MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");
		
		
		
		
		Connection conn;
    	PreparedStatement stmt;  
			try {
		 conn = ds.getConnection();
		 stmt = conn.prepareStatement("INSERT INTO RegisterDetails  VALUES (?,?,?,?,?,?,?)");
         stmt.setString(1, FullName);
         stmt.setString(2, Address);
         stmt.setString(3, Age);
         stmt.setString(4, mobile);
         stmt.setString(5, emailid_ID);
         stmt.setString(6, verification);
	     stmt.setString(7, country);
	     stmt.execute();
        

       

        // Close all the connections
        stmt.close();
        conn.close();

        // Get a writer pointer 
        // to display the successful result
        PrintWriter out = res.getWriter();
        out.println("<html><body><b>Successfully Inserted"
                    + "</b></body></html>");
    }
    catch (Exception e) {
        e.printStackTrace();
    }
		
		res.sendRedirect("/review-page");
}
}


