package com.anychart.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.anychart.models.FlightDetails;
import com.anychart.models.RegisterDetails;
import com.mysql.cj.jdbc.MysqlDataSource;

/**
 * Servlet implementation class ReviewServlet
 */
@WebServlet("/ReviewServlet")
public class ReviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReviewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session= req.getSession(); 

		String flightId=(String)session.getAttribute("user_flight_Id");
		String emailId=(String)session.getAttribute("user_email_Id");
		
		
	  	MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");
	  	String flightStatus = "";
    	Connection conn;
    	PreparedStatement stmt;
    	PreparedStatement stmt1;
    	List<FlightDetails> flights = new ArrayList<FlightDetails>();
    	List<RegisterDetails> registered_user = new ArrayList<RegisterDetails>();
    	
    	
    	try {
    			 conn = ds.getConnection();
	             stmt = conn.prepareStatement("select * from FlightDetails where flight_no_ID = ?");
	             stmt.setString(1, flightId);
	             //stmt.setString(1, "8934");
	             
	             ResultSet rs = stmt.executeQuery();			             
	             // Extract data from result set
	             while (rs.next()) {
	                 //Retrieve by column name
	                 String airline_name = rs.getString("airline_name");
	                 int price = rs.getInt("price");
	                 int flight_no_ID = rs.getInt("flight_no_ID");
	                 String source_city1 = rs.getString("source_city");
	                 String destination_city1 = rs.getString("destination_city");
	                 String departure_time = rs.getString("departure_time");
	                 String arrival_time = rs.getString("arrival_time");
	                 int total_seats = rs.getInt("total_seats");
	                 int booked_seats = rs.getInt("booked_seats");
	                 int available_seats = rs.getInt("available_seats");
	                 String date_of_travel1 = rs.getString("date_of_travel");			                 
	                 
	                 FlightDetails fd = new FlightDetails(airline_name, price, flight_no_ID, source_city1, destination_city1, departure_time,
	                 		arrival_time, total_seats, booked_seats, available_seats, date_of_travel1);
	                 flights.add(fd);                
	                 // Add item
	             }
	             stmt1 = conn.prepareStatement("select * from RegisterDetails where emailid_ID = ?");
	             stmt1.setString(1, emailId);
	             //stmt1.setString(1, "lils@lils.coom");

	             
	             ResultSet rs1 = stmt1.executeQuery();			             
	             // Extract data from result set
	             while (rs1.next()) {
	                 //Retrieve by column name
	                 String FullName = rs1.getString("FullName");
	                 String Address = rs1.getString("Address");
	                 int Age = rs1.getInt("Age");
	                 int mobile = rs1.getInt("mobile");
	                 String email = rs1.getString("emailid_ID");
	                 String verification = rs1.getString("verification");
	                 String country = rs1.getString("country");
	                 
	                 
	               			                
	                 
	                 RegisterDetails rd = new RegisterDetails(FullName, Address, Age, mobile, email, verification, country);
	                 registered_user.add(rd);                
	                 // Add item
	             }

	         			        	
    	} 
    	catch (Exception e) {
    		e.printStackTrace();
    	}
        
				
		req.setAttribute("selectedFlightData", flights);
		req.setAttribute("registeredUserData", registered_user);
		



        req.getRequestDispatcher("/WEB-INF/views/ReviewPage.jsp").forward(req, res);

    	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

	}

}
