package com.anychart.servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.anychart.models.FlyAway;
import com.mysql.cj.jdbc.MysqlDataSource;

public class FlyAwayServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");

        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT  source_city, destination_city, date_of_travel  FROM FlightDetails")) {

            List<FlyAway> flights = new ArrayList<FlyAway>();
            // Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                
                String source_city = rs.getString("source_city");
                String destination_city = rs.getString("destination_city");
                String date_of_travel = rs.getString("date_of_travel");
                


                
                
                FlyAway fd = new FlyAway(source_city, destination_city, date_of_travel);
                flights.add(fd);                
                // Add item
            }

            req.setAttribute("title", "Search Flight");
            req.setAttribute("flightSearchData", flights);
            req.getRequestDispatcher("/WEB-INF/views/FlyAway.jsp").forward(req, resp);
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
}
