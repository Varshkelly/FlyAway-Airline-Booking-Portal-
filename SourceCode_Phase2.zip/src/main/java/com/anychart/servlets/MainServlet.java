package com.anychart.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.anychart.models.FlightDetails;
import com.mysql.cj.jdbc.MysqlDataSource;

public class MainServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");

        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT airline_name, price, flight_no_ID, source_city, destination_city, departure_time, arrival_time,"
             		+ "total_seats, booked_seats, available_seats, date_of_travel  FROM FlightDetails")) {

            List<FlightDetails> flights = new ArrayList<FlightDetails>();
            // Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String airline_name = rs.getString("airline_name"); 
                int price = rs.getInt("price");
                int flight_no_ID = rs.getInt("flight_no_ID");
                String source_city = rs.getString("source_city");
                String destination_city = rs.getString("destination_city");
                String departure_time = rs.getString("departure_time");
                String arrival_time = rs.getString("arrival_time");
                int total_seats = rs.getInt("total_seats");
                int booked_seats = rs.getInt("booked_seats");
                int available_seats = rs.getInt("available_seats");
                String date_of_travel = rs.getString("date_of_travel");
                
                
                FlightDetails fd = new FlightDetails(airline_name, price, flight_no_ID, source_city, destination_city, departure_time,
                		arrival_time, total_seats, booked_seats, available_seats, date_of_travel);
                flights.add(fd);                
                // Add item
            }

            req.setAttribute("title", "Flight Details from Database");
            req.setAttribute("flightData", flights);
            req.getRequestDispatcher("/WEB-INF/views/Dashboard.jsp").forward(req, resp);
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
