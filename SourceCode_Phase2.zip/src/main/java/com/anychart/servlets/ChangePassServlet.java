package com.anychart.servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.jdbc.MysqlDataSource;


public class ChangePassServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	

	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       
			String old_password = req.getParameter("old");
			String new_password = req.getParameter("new");
			HttpSession session= req.getSession(); 
			String username=(String)session.getAttribute("loggedin_user");

			
			  	MysqlDataSource ds = (MysqlDataSource) req.getServletContext().getAttribute("DBDataSource");
			  	String ChangePass = "";
	        	Connection conn;
	        	PreparedStatement stmt;
	        	PreparedStatement stmt1;
	        	String db_pass = "";
	        	try {
	        			 conn = ds.getConnection();
			             stmt = conn.prepareStatement("select password from AdminLogin where UsernameID = ? ");
			             stmt.setString(1, username);
			             ResultSet rs = stmt.executeQuery();
			        	 if(rs.next()) {
			        		db_pass= rs.getString("password");
			        		
			        		if(db_pass.equals(old_password)) {	
			        			
			        			stmt1 = conn.prepareStatement("update AdminLogin set password = ? where UsernameID = ? ");
					            stmt1.setString(1, new_password);
					            stmt1.setString(2, username);
					            int rows = stmt1.executeUpdate();
					            if(rows > 0) {
					            	ChangePass = "Success";
					            }			        			
			        			
			        		} else {
			        			ChangePass = "Failed";
			        		}
			        		
		        			

			        	 }
	        	}
			        	
			        	 
	        	 
	        	catch (Exception e) {
	        		e.printStackTrace();
	        	}
		        
					req.setAttribute("passStatus", ChangePass);
					req.setAttribute("dbPass", db_pass);
		            req.getRequestDispatcher("/WEB-INF/views/ChangePass.jsp").forward(req, resp);
		    }  

}
