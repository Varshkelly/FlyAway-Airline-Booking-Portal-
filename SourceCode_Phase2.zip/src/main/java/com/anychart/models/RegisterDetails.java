package com.anychart.models;

public class RegisterDetails {
	private String fullName;
	private String address;
	private int age;
	private int mobile;
	private String emailid_ID;
	private String verification;
	private String country;
	
	 public RegisterDetails(String fullName2, String address2, int age2, int mobile2, String emailid_ID2, String verification2, String country2 ) { 
	    		
	    	this.fullName = fullName2;
	    	this.address = address2;
	    	this.age = age2;
	    	this.mobile = mobile2;
	    	this.emailid_ID = emailid_ID2;
	    	this.verification = verification2;
	    	this.country = country2;
//	    	
	 }
	    	
	public String getFullName() {
		return this.fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getAddress() {
		return this.address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return this.age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getEmailid_ID() {
		return emailid_ID;
	}
	public void setEmailid_ID(String emailid_ID) {
		this.emailid_ID = emailid_ID;
	}
	public String getVerification() {
		return verification;
	}
	public void setVerification(String verification) {
		this.verification = verification;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
}
