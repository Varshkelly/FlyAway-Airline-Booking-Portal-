package com.anychart.models;

public class AdminLogin {
	private String password;
	private String username;
	public AdminLogin(String usernameID2, String password2) {
		this.username = usernameID2;
    	this.password = password2;
	}
	public String getUsernameID() {
		return username;
	}
	public void setUsernameID(String usernameID) {
		username = usernameID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
