package com.anychart.models;

public class FlyAway {

    
    private String source_city;
    private String destination_city;
    private String date_of_travel;
    
    public FlyAway(String source_city2, String destination_city2,String date_of_travel2) {
    	this.source_city = source_city2;
    	this.destination_city = destination_city2;
    	this.date_of_travel = date_of_travel2;
    	
	}
	public String getSource_city() {
		return source_city;
	}
	public void setSource_city(String source_city) {
		this.source_city = source_city;
	}
	public String getDestination_city() {
		return destination_city;
	}
	public void setDestination_city(String destination_city) {
		this.destination_city = destination_city;
	}
	public String getDate_of_travel() {
		return date_of_travel;
	}
	public void setDate_of_travel(String date_of_travel) {
		this.date_of_travel = date_of_travel;
	}

  
}
