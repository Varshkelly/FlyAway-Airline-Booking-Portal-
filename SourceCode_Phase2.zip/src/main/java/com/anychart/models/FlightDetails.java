package com.anychart.models;

public class FlightDetails {

    private String airline_name;
    private int price;
    private int flight_no_ID;
    private String source_city;
    private String destination_city;
    private String  departure_time;
    private String arrival_time;
    private int total_seats;
    private int booked_seats;
    private int available_seats;
    private String date_of_travel;
    
    public FlightDetails(String airline_name2, int price2, int flight_no_ID2, String source_city2, String destination_city2, 
    		String  departure_time2, String arrival_time2, int total_seats2, int booked_seats2, int available_seats2, String date_of_travel2) {
    	this.airline_name = airline_name2;
    	this.price = price2;
    	this.flight_no_ID = flight_no_ID2;
    	this.source_city = source_city2;
    	this.destination_city = destination_city2;
    	this.departure_time = departure_time2;
    	this.arrival_time = arrival_time2;
    	this.total_seats = total_seats2;
    	this.booked_seats = booked_seats2;
    	this.available_seats = available_seats2;
    	this.date_of_travel = date_of_travel2;
    	
	}
	   
	
	public String getAirline_name() {
		return airline_name;
	}
	public void setAirline_name(String airline_name) {
		this.airline_name = airline_name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getFlight_no_ID() {
	return flight_no_ID;
	}
	public void setFlight_no_ID(int flight_no_ID) {
		this.flight_no_ID = flight_no_ID;
	}
	public String getSource_city() {
		return source_city;
	}
	public void setSource_city(String source_city) {
		this.source_city = source_city;
	}
	public String getDestination_city() {
		return destination_city;
	}
	public void setDestination_city(String destination_city) {
		this.destination_city = destination_city;
	}
	public String getDeparture_time() {
		return departure_time;
	}
	public void setDeparture_time(String departure_time) {
		this.departure_time = departure_time;
	}
	public String getArrival_time() {
		return arrival_time;
	}
	public void setArrival_time(String arrival_time) {
		this.arrival_time = arrival_time;
	}
	public int getTotal_seats() {
		return total_seats;
	}
	public void setTotal_seats(int total_seats) {
		this.total_seats = total_seats;
	}
	public int getBooked_seats() {
		return booked_seats;
	}
	public void setBooked_seats(int booked_seats) {
		this.booked_seats = booked_seats;
	}
	public int getAvailable_seats() {
		return available_seats;
	}
	public void setAvailable_seats(int available_seats) {
		this.available_seats = available_seats;
	}
	public String getDate_of_travel() {
		return date_of_travel;
	}
	public void setDate_of_travel(String date_of_travel) {
		this.date_of_travel = date_of_travel;
	}

  
}
